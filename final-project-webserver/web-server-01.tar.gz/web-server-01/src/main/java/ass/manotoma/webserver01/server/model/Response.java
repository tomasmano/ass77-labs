package ass.manotoma.webserver01.server.model;

/**
 *
 * @author Tomas Mano <tomasmano@gmail.com>
 */
public interface Response {
    
}
