package ass.manotoma;

/**
 * Created with IntelliJ IDEA.
 * User: jajusko
 * Date: 3/5/13
 * Time: 11:58 AM
 * To change this template use File | Settings | File Templates.
 */
public interface Sorter {

    void sort(double[] data) throws Exception;

}
